#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

// Velmoria (HUD-Umbau 27.11.2026): Original 1.21.11 + Verschiebung der HUD-Zeichen an den linken Bildschirmrand.
// HUD-Zeichen erkennt man an leicht verschobenen Farben (Core hud/HudService.MARK) bzw. ihren Schatten (Farbe / 4).
// Nur im GUI (orthografische Projektion, ProjMat[3][3] == 1) – Welt-Text (Schilder, Hologramme) bleibt unverändert.
// Die HUD-Zeilen haben in der Aktionsleiste netto 0 px Breite → ihr Startpunkt ist genau die Bildschirmmitte (GUI-Breite / 2).

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

const float MARGIN = 5.0;        // Abstand zum linken Rand (GUI-Pixel)
const float NARROW = 454.0;      // schmaler als das → HUD würde Offhand-Slot berühren → nach oben
const float RAISE = 46.0;        // so weit nach oben (über Rüstungsanzeige/Item-Namen)

const ivec3 MARK[9] = ivec3[](ivec3(250,250,251), ivec3(166,166,167), ivec3(82,82,83), ivec3(250,82,82), ivec3(82,82,250),
                              ivec3(166,2,166), ivec3(250,250,82), ivec3(250,166,2), ivec3(82,250,82));

bool isHud(vec3 c) {
    ivec3 v = ivec3(c * 255.0 + 0.5);
    for (int i = 0; i < 9; i++) {
        if (v == MARK[i] || v == MARK[i] / 4) return true;
    }
    return false;
}

void main() {
    vec3 pos = Position;
    if (ProjMat[3][3] == 1.0 && isHud(Color.rgb)) {
        float guiW = 2.0 / ProjMat[0][0];
        pos.x += MARGIN - guiW * 0.5;
        if (guiW < NARROW) pos.y -= RAISE;
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
