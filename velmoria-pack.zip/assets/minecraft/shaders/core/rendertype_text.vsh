#version 330

#define MAP_DEPTH -0.9999
#define MARKER_DEPTH -0.9999

#moj_import <nminimap:config.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

flat out int custom;
out vec2 uvCoord;
flat out vec3 b_meta;
flat out vec4 box;

#moj_import <nminimap:vertex_utils.glsl>

// ---- Velmoria-HUD v2 (27.11.2026) – wird von make_hud.py in den NMinimap-Shader eingesetzt -------------------
// HUD-Zeichen tragen ihren Anker in der Textfarbe: G&7 = 5 und B&7 = 3 (Kennung, kommt bei Vanilla-Farben nie vor), R&7 = Anker.
// Die Aktionsleiste ist netto 0 px breit → ihr Start = Bildschirmmitte, ihre Oberkante = H − VH_AB (Vanilla).
// Nur im GUI (orthografisch). Unter der Minikarte (Anker 2) wird aus NMinimaps MAP_OFFSET/MAP_SIZE (Bildschirm-Pixel) gerechnet.
const float VH_M = 4.0;     // Abstand zum Rand (GUI-Pixel)
const float VH_AB = 72.0;   // Aktionsleiste: Oberkante des Textes = H − 72

int vhAnchor(vec4 c) {
    ivec3 v = ivec3(c.rgb * 255.0 + 0.5);
    if ((v.g & 7) == 5 && (v.b & 7) == 3 && (v.r & 7) <= 6) return v.r & 7;
    return -1;
}

vec3 vhPos(vec3 p, vec4 c) {
    if (ProjMat[3][3] != 1.0) return p;
    int a = vhAnchor(c);
    if (a < 0) return p;
    float W = 2.0 / ProjMat[0][0];
    float H = abs(2.0 / ProjMat[1][1]);
    float gs = ScreenSize.x / W;
    float x0 = (a == 0 || a == 3 || a == 4) ? VH_M : (a == 1 || a == 5) ? W * 0.5 : W - VH_M;
    float y0 = (a <= 2) ? VH_M : (a == 3) ? H * 0.5 - 80.0 : H - 160.0;
    if (a == 2) {
        x0 = W - MAP_OFFSET.x / gs;
        y0 = (MAP_OFFSET.y + MAP_SIZE.y) / gs + 4.0;
    }
    if (a == 1 && W < 360.0) y0 += 30.0;   // schmal: Mob-Leiste unter die Spielerkarte
    if (a == 6 && W < 430.0) y0 -= 36.0;   // schmal: Geld über die Mana-Kugel
    p.x += x0 - W * 0.5;
    p.y += y0 - (H - VH_AB);
    return p;
}

void main() {
    custom = 0;
    uvCoord = vec2(0);
    b_meta = vec3(0);
    box = vec4(0);

    gl_Position = ProjMat * ModelViewMat * vec4(vhPos(Position, Color), 1.0); // Velmoria-HUD

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;

    #moj_import <nminimap:vertex_body.glsl>
}
