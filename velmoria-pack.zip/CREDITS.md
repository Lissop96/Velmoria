# Velmoria – Credits

Die folgenden 3D-Modelle stammen von [Blockbench Workshop](https://blockbenchworkshop.com) und stehen unter
**CC BY 4.0** (Namensnennung, <https://creativecommons.org/licenses/by/4.0/>) bzw. **CC0 1.0** (gemeinfrei). Im Spiel: `/credits`.

| Modell | Autor | Quelle | Lizenz | Änderungen |
|---|---|---|---|---|
| Goblin Scout | @yair | https://blockbenchworkshop.com/model/yair/goblin-scout | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, Animation „death“ ergänzt |
| Dead Traveler (Skeleton) | @polyjo | https://blockbenchworkshop.com/model/polyjo/dead-traveler-skeleton | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, „slash“ → „attack“, Animation „death“ ergänzt |
| Pale Hound | @everythingisawsome | https://blockbenchworkshop.com/model/everythingisawsome/pale-hound | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Sketchfab-Hüllen aufgelöst (217 → 18 Bones), Meshes in Würfel umgerechnet, Loops korrigiert, Animationen „attack“/„death“ ergänzt ⚠ Hochgeladen von everythingisawsome („Authorized to redistribute“, nicht als eigenes Werk) – ursprünglich ein Sketchfab-Modell, Urheber ungeklärt. |
| Succubus | @logan_kant | https://blockbenchworkshop.com/model/logan_kant/succubus | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) | Format GeckoLib → Generic, Animationen „attack“/„cast“/„death“ ergänzt |
| Skeleton Lord | @anim | https://blockbenchworkshop.com/model/anim/skeleton-lord | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Leere Animationen entfernt, Loop korrigiert, Bone umbenannt, Animationen „attack“/„death“ ergänzt |
| Redstone Golem (Minecraft Dungeons) | @polyjo | https://blockbenchworkshop.com/model/polyjo/redstone-golem-minecraft-dungeons | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, Animationen „attack“/„slam“/„death“ ergänzt ⚠ Figur aus „Minecraft Dungeons“ (Mojang). Nur kostenlos verwenden – nicht in Shops, Rängen oder bezahlten Kisten. |
| THE_ENTITY | @nori | https://blockbenchworkshop.com/model/nori/the-entity | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Textur 4096 → 1024 verkleinert, leere Animation entfernt, Animationen „attack“/„death“ ergänzt |
| Runestone Warden Golem | @yair | https://blockbenchworkshop.com/model/yair/runestone-warden-golem | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht |
| Tyrannosaurus Rex Skeleton | @octopuslab | https://blockbenchworkshop.com/model/octopuslab/tyrannosaurus-rex | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Format → Generic, Loop korrigiert |
| Fire Dragon Minecraft | @nyxaris | https://blockbenchworkshop.com/model/nyxaris/fire-dragon-minecraft | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Animationen „idle“/„walk“/„attack“/„fire“/„death“ ergänzt (Bodenpose) |
| Kintsugi | @eanncrod | https://blockbenchworkshop.com/model/eanncrod/kintsugi | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Format Bedrock → Generic, Animationen umbenannt (hover_move → walk, bite → attack) |
| MORGHUL Bestia Otchlani | @nyxaris | https://blockbenchworkshop.com/model/nyxaris/morghul-bestia-otchlani | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | 536 Freiform-Meshes durch gedrehte Würfel ersetzt (Minecraft kann keine Meshes), Namen gesäubert |

_Stand: 26.11.2026_
