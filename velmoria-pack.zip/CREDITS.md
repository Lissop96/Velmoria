# Velmoria – Credits

Die folgenden 3D-Modelle stehen unter der Lizenz **Creative Commons Namensnennung 4.0 International (CC BY 4.0)**
– <https://creativecommons.org/licenses/by/4.0/>. Im Spiel: `/credits`.

| Modell | Autor | Quelle | Lizenz | Änderungen |
|---|---|---|---|---|
| Goblin Scout | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, Animation „death“ ergänzt |
| Dead Traveler (Skeleton) | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, „slash“ → „attack“, Animation „death“ ergänzt |
| Pale Hound | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Sketchfab-Hüllen aufgelöst (217 → 18 Bones), Meshes in Würfel umgerechnet, Loops korrigiert, Animationen „attack“/„death“ ergänzt |
| Succubus | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Format GeckoLib → Generic, Animationen „attack“/„cast“/„death“ ergänzt |
| Skeleton Lord | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Leere Animationen entfernt, Loop korrigiert, Bone umbenannt, Animationen „attack“/„death“ ergänzt |
| Redstone Golem | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, Animationen „attack“/„slam“/„death“ ergänzt ⚠ Figur aus „Minecraft Dungeons“ (Mojang). Nur kostenlos verwenden – nicht in Shops, Rängen oder bezahlten Kisten. |
| The Entity | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Textur 4096 → 1024 verkleinert, leere Animation entfernt, Animationen „attack“/„death“ ergänzt |
| Runestone Warden Golem | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht |
| Tyrannosaurus Rex | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Format → Generic, Loop korrigiert |
| Fire Dragon | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Animationen „idle“/„walk“/„attack“/„fire“/„death“ ergänzt (Bodenpose) |
| Kintsugi | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Format Bedrock → Generic, Animationen umbenannt (hover_move → walk, bite → attack) |
| MORGHUL – Bestia Otchlani | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | 536 Freiform-Meshes durch gedrehte Würfel ersetzt (Minecraft kann keine Meshes), Namen gesäubert |

_Stand: 25.11.2026_
