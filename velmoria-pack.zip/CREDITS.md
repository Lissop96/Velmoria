# Velmoria – Credits

Die folgenden 3D-Modelle stehen unter **CC BY 4.0** (Namensnennung, <https://creativecommons.org/licenses/by/4.0/>) bzw. **CC0 1.0** (gemeinfrei),
die meisten von [Blockbench Workshop](https://blockbenchworkshop.com). Im Spiel: `/credits`.

| Modell | Autor | Quelle | Lizenz | Änderungen |
|---|---|---|---|---|
| Goblin Scout | @yair | https://blockbenchworkshop.com/model/yair/goblin-scout | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, Animation „death“ ergänzt |
| Dead Traveler (Skeleton) | @polyjo | https://blockbenchworkshop.com/model/polyjo/dead-traveler-skeleton | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, „slash“ → „attack“, Animation „death“ ergänzt |
| Pale Hound | @everythingisawsome | https://blockbenchworkshop.com/model/everythingisawsome/pale-hound | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Sketchfab-Hüllen aufgelöst (217 → 18 Bones), Meshes in Würfel umgerechnet, Loops korrigiert, Animationen „attack“/„death“ ergänzt ⚠ Hochgeladen von everythingisawsome („Authorized to redistribute“, nicht als eigenes Werk) – ursprünglich ein Sketchfab-Modell, Urheber ungeklärt. |
| Succubus | @logan_kant | https://blockbenchworkshop.com/model/logan_kant/succubus | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) | Format GeckoLib → Generic, Animationen „attack“/„cast“/„death“ ergänzt |
| Skeleton Lord | @anim | https://blockbenchworkshop.com/model/anim/skeleton-lord | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Leere Animationen entfernt, Loop korrigiert, Bone umbenannt, Animationen „attack“/„death“ ergänzt |
| Redstone Golem (Minecraft Dungeons) | @polyjo | https://blockbenchworkshop.com/model/polyjo/redstone-golem-minecraft-dungeons | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, Animationen „attack“/„slam“/„death“ ergänzt ⚠ Figur aus „Minecraft Dungeons“ (Mojang). Nur kostenlos verwenden – nicht in Shops, Rängen oder bezahlten Kisten. |
| THE_ENTITY | @nori | https://blockbenchworkshop.com/model/nori/the-entity | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Textur 4096 → 1024 verkleinert, leere Animation entfernt, Animationen „attack“/„death“ ergänzt |
| Runestone Warden Golem | @yair | https://blockbenchworkshop.com/model/yair/runestone-warden-golem | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht |
| Tyrannosaurus Rex Skeleton | @octopuslab | https://blockbenchworkshop.com/model/octopuslab/tyrannosaurus-rex | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Format → Generic, Loop korrigiert |
| Fire Dragon Minecraft | @nyxaris | https://blockbenchworkshop.com/model/nyxaris/fire-dragon-minecraft | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Animationen „idle“/„walk“/„attack“/„fire“/„death“ ergänzt (Bodenpose) |
| Kintsugi | @eanncrod | https://blockbenchworkshop.com/model/eanncrod/kintsugi | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Format Bedrock → Generic, Animationen umbenannt (hover_move → walk, bite → attack) |
| MORGHUL Bestia Otchlani | @nyxaris | https://blockbenchworkshop.com/model/nyxaris/morghul-bestia-otchlani | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | 536 Freiform-Meshes durch gedrehte Würfel ersetzt (Minecraft kann keine Meshes), Namen gesäubert |
| Sludgebottle Toxic Slime | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, hop → walk |
| Geodeheart Crystal Slime | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, hop → walk |
| Zapjelly Spark Slime | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, hop → walk |
| Snapmaw Flytrap | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, triple_snap → attack, hop → walk ⚠ Laut Datei KI-unterstützt erstellt (ai_used). |
| Warbanner Orc Chieftain | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht |
| Drumthump Goblin Drummer | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht |
| Tidecaller Orb | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, surge_forward → walk, evaporate → death ⚠ Laut Datei KI-unterstützt erstellt (ai_used). |
| Spinecannon Beast | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht |
| Tidepool Hermit | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht ⚠ Laut Datei KI-unterstützt erstellt (ai_used). |
| Rollo Delivery Bot | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht ⚠ Laut Datei KI-unterstützt erstellt (ai_used). |
| Domeshell Crawler | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, crawl → walk, vent_steam → attack, Animation „death“ ergänzt |
| Rootmaw Stump | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, Animationen „walk“/„attack“/„death“ ergänzt ⚠ Laut Datei KI-unterstützt erstellt (ai_used). |
| Bronze Bull Warden | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, Animationen „walk“/„attack“/„charge“/„death“ ergänzt ⚠ Laut Datei KI-unterstützt erstellt (ai_used). |
| Velvet Flitter | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, Animationen „attack“/„death“ ergänzt, idle = Flug ⚠ Laut Datei KI-unterstützt erstellt (ai_used). |
| Wavecutter Cat | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, Animation „death“ ergänzt |
| Rotorwarden Heli | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, Animation „death“ ergänzt |
| Ironwhistle Loco | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, Animation „death“ ergänzt ⚠ Laut Datei KI-unterstützt erstellt (ai_used). |
| Grindstone Dozer | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, Animation „death“ ergänzt |
| Twinsaw Lumberbot | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, drive → walk, Animation „death“ ergänzt |
| Tricrest Horned Dino | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, Animationen „death“/„charge“ ergänzt ⚠ Laut Datei KI-unterstützt erstellt (ai_used). |
| Cinderblob Fire Slime | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, hop → walk ⚠ Laut Datei KI-unterstützt erstellt (ai_used). |
| Frostcube Ice Slime | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht, hop → walk |
| Tuskhelm Orc Brute | <<AUTOR>> | <<LINK>> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Namen vereinheitlicht |

_Stand: 27.11.2026_
